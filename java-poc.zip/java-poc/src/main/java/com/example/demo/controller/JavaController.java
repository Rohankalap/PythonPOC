package com.example.demo.controller;

import java.io.FileReader;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Topic;
import com.example.demo.service.ServiceClass;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/firemon")
public class JavaController {

	@Autowired
	private ServiceClass service;
	
	@GetMapping
	public String test()
	{
		System.out.println("into java testing");
		return "test positive";
	}
	
	@GetMapping("/topics")
	public List<Topic> getTopic()
	{
		System.out.println("getting data from service");
		return service.getAllTopics();
	}
	
	@GetMapping("/topics/{id}")
	public Topic putTopicId(@PathVariable String id)
	{
		System.out.println("id got from python "+id);
		
		return new Topic(id,"name","description");
	}
	
	@GetMapping("/param")
	public String parameterMapping(@RequestParam String str)
	{
		System.out.println("param request data is "+str);
		
		return str;
	}
	
	@GetMapping("/request")
	public String requestBodyMapping(@RequestBody String body)
	{
		System.out.println("request body data is "+body);
		
		return body;
	}
	
	 @PostMapping("/file")
	    public void uploadFile(@RequestParam("file") MultipartFile file) {
	        System.out.println("into file function");
		 System.out.println(file.getName());
		 System.out.println(file.getSize());
	    }
}
