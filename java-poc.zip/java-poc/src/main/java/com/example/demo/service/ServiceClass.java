package com.example.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Topic;

@Service
public class ServiceClass {
	 
	 public List<Topic> getAllTopics()
	 {
		 List<Topic> topicList = new ArrayList<>(Arrays.asList(
		            new Topic("_spring", "_Spring FrameWork", "_Spring Description"),
		            new Topic("angular", "angular 8", "angular description"),
		            new Topic("java", "Java FrameWork", "Java Description")

		    ));
		 return topicList;
	 }
}
