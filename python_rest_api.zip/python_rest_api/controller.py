from flask import Flask, jsonify
from flask_restful import Resource, Api
from flask_cors import CORS, cross_origin           # avoid cross origin error
import cli_task_file                                #import cli cmd file
import requests                                     # for api requests to java

app = Flask(__name__)
api = Api(app)
CORS(app)

@app.route("/")
def hello():
    return jsonify({'text':'Hello World welcome to python lab!'})       #default api for python

class Employees(Resource):
    def get(self):
        return {'employees': [{'id':1, 'name':'Balram'},{'id':2, 'name':'Tom'}]}    #python  api returns employee object array

class Student(Resource):
    def get(self):
        print("student data")
        return {'id':1, 'name':'Cal','age':20, 'college':'FC','branch':'science', 'city':'Pune'}    #python  api returns object

class Cli_files(Resource):
    def get(self):
        cli_task_file.read_file()                   #access read file function of cli.py file
        return "done"

class get_Cli_files(Resource):                      # to access cli get data function
    def get(self):
        cli_task_file.get_cli_data()
        return "done"

class call_java_topics(Resource):
    def get(self):
        ret=requests.get("http://localhost:8060/firemon/topics")        #java API to call
        print(ret.content)                              # print content of response
        return ret.json()

class call_java_test(Resource):
    def get(self):
        ret=requests.get("http://localhost:8060/firemon/")
        return ret.json()                               #return json data

class java_pass_pathvariable(Resource):
    def get(self):
        ret=requests.get("http://localhost:8060/firemon/topics/10")     #pass as path variable
        return ret.json()

class java_param(Resource):
    def get(self):
        body = "stay home stay safe"
        ret=requests.get("http://localhost:8060/firemon/param",params=body)      #pass as parameter
        return ret.status_code

class java_requestbody(Resource):
    def get(self):
        body = "stay home stay safe"
        ret=requests.get("http://localhost:8060/firemon/request",data=body)        #pass as request body
        return ret.status_code

class java_file(Resource):
    def get(self):
        file = {'file': open('dir.txt','rb')}
        ret=requests.post("http://localhost:8060/firemon/file",files = file)        #pass as request body
        return ret.status_code


#python api mappings

api.add_resource(Cli_files, '/readfiles') # Route_1             @output of thhese API are shown in python console
api.add_resource(get_Cli_files, '/getfiles') # Route_2

api.add_resource(Employees, '/employees') # Route_3             #these API return to Angular call
api.add_resource(Student, '/student') # Route_4

#these are mappings for java api to hit from url
# like http://127.0.0.1:5002/file

api.add_resource(call_java_test, '/javatest') # Route_5         # hit java api to test
api.add_resource(call_java_topics, '/javatopics') # Route_6        # these are python api to hit java function
api.add_resource(java_pass_pathvariable, '/javapath') # Route_7     # pass path variable to java api
api.add_resource(java_param, '/javaparam') # Route_8                #pass as requestparameter to java
api.add_resource(java_requestbody, '/javabody') # Route_9           # pass as request body to java
api.add_resource(java_file, '/file') # Route_10                     #to pass file to java API

if __name__ == '__main__':
    app.run(port=5002)