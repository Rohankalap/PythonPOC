import os
#import subprocess

#commands to excecute on cmd
cmds = {
    "ping" : "ping 172.22.22.84",
    "dir" : "dir",
    "ipconfig": "ipconfig"
}

#to store cmds result
data = {}

def call_java():
    for val in cmds:
        try:  # open file if exist
            file = open(val + ".txt", 'r')
            print(file.name)
            file.close()
        except IOError:
            print("File not accessible")
            print()

def read_file():
        for val in cmds:
            try:  # open file if exist
                file = open(val+".txt",'r')
                for line in file:
                    if not line.strip():                #remove empty lines
                        continue;
                    print(line)                         # read file
                print("-------------------------------------------")
                file.close()
            except IOError:
                print("File not accessible")
                print()

def get_cli_data():
    for val in cmds:
        print(val," file created")
        print()
        var = os.popen(cmds[val]).readlines()           # get data from cmd prompt
        file = open(val+".txt", 'w')                    # create text file
        for line in var:
            if not line.strip():
                continue;
            file.write(line)                            # write data to file
            file.write("\n")

if __name__ =='__main__':
    print("started program")
    while(True):
        choice = int(input("enter your choice \n 1:get data from cli  \n 2: read data from file \n 3: exit"))
        if choice == 1:
            get_cli_data()              #read data from cmd prompt
        if choice == 2:
            read_file()                 # print all data from file
        if choice ==3:
            break
    print("done")